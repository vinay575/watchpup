﻿using System.ComponentModel.DataAnnotations;

namespace WatchPupWeb.Models
{
    public class UserLoginModel
    {
        [Required]
        [EmailAddress]
        public string EmailAddress { get; set; }

        [Required]
        public string Password { get; set; }
    }

    public class SearchViewModel
    {
        [Required]
        public string userIdsearchCriteria { get; set; }
    }
}
