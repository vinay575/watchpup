using PayPal.Sdk.Checkout.Authentication;
using PayPal.Sdk.Checkout.ContractEnums;
using PayPal.Sdk.Checkout.Core.Interfaces;
using PayPal.Sdk.Checkout.Extensions;
using PayPal.Sdk.Checkout.Subscriptions;
using System;
using System.Threading.Tasks;
using DataAccessLibrary.Models;

namespace WatchPupWeb.Paypal;

public static class ShowUserSubscriptionDetails
{
    /// <summary>
    /// Below function can be used to create a subscription with complete payload.
    /// </summary>
    public static async Task<Subscription?> ShowSubscriptionDetails(this IPayPalHttpClient httpClient, AccessToken accessToken, string subscriptionId, bool debug = false)
    {
        Console.WriteLine("Creating Subscription with complete payload");
        var response = await httpClient.ShowSubscriptionDetailsAsync(accessToken, subscriptionId,  request =>
        {
            request.SetPreferReturn(EPreferReturn.Representation);
            //request.SetRequestBody(BuildRequestBody(subscriptionModel));
        });

        if (debug && response != null)
        {
            
        }

        return response;
    }
}
