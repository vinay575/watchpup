using PayPal.Sdk.Checkout.Authentication;
using PayPal.Sdk.Checkout.ContractEnums;
using PayPal.Sdk.Checkout.Core.Interfaces;
using PayPal.Sdk.Checkout.Extensions;
using PayPal.Sdk.Checkout.Subscriptions;
using System;
using System.Threading.Tasks;
using DataAccessLibrary.Models;
using WatchPupWeb.Data;

namespace WatchPupWeb.Paypal;

public static class CreateUserSubscription
{
    /// <summary>
    /// Below function can be used to build the create order request body with complete payload.
    /// </summary>
    
    private static SubscriptionRequest BuildRequestBody(SubscriptionModel subscriptionModel)
    {
        DateTime startTime = DateTime.UtcNow;
        //string startTimeFormatted = startTime.ToString("yyyy-MM-ddTHH:mm:ssZ");
        
        var isoDate = DateTime.Now;
        isoDate = isoDate.AddDays(1);
        
        string startTimeFormatted = isoDate.ToString("yyyy-MM-ddTHH:mm:ssZ");

        var subscriptionRequest = new SubscriptionRequest
        {
            PlanId = subscriptionModel.PlanId,  // "P-6W79684254961700SMUVAU3I",
            StartTime = startTimeFormatted,
            Quantity = "1",
            Subscriber = new Subscriber
            {
                Name = new Name
                {
                    GivenName = DataUtil.FirstName,
                    Surname = DataUtil.LastName
                },
                EmailAddress = DataUtil.UserName,
            },
            ApplicationContext = new ApplicationContext
            {
                BrandName = DataUtil.SiteName,
                Locale = "en-US",
                ShippingPreference = "NO_SHIPPING",
                PaymentMethod = new PaymentMethod
                {
                    PayerSelected = "PAYPAL",
                    PayeePreferred = "IMMEDIATE_PAYMENT_REQUIRED"
                },
                CancelUrl = DataUtil.CancelURL, // "https://localhost:5001/dashboard",

                ReturnUrl = DataUtil.ReturnURL  //"https://localhost:5001/subscriptionprocessor"
            },
        };
            
        return subscriptionRequest;
    }

    /// <summary>
    /// Below function can be used to create a subscription with complete payload.
    /// </summary>
    public static async Task<Subscription?> CreateSubscription(this IPayPalHttpClient httpClient, AccessToken accessToken, SubscriptionModel subscriptionModel, bool debug = false)
    {
        Console.WriteLine("Creating Subscription with complete payload");
        var response = await httpClient.CreateSubscriptionAsync(accessToken, request =>
        {
            request.SetPreferReturn(EPreferReturn.Representation);
            request.SetRequestBody(BuildRequestBody(subscriptionModel));
        });

        if (debug && response != null)
        {
            //Console.WriteLine("Status: {0}", response.Status);
            //Console.WriteLine("Order Id: {0}", response.Id);
            //Console.WriteLine("Intent: {0}", response.CheckoutPaymentIntent);
            //Console.WriteLine("Links:");
            //foreach (var link in response.Links)
            //{
            //    Console.WriteLine("\t{0}: {1}\tCall Type: {2}", link.Rel, link.Href, link.Method);
            //}

            //var amount = response.PurchaseUnits.Single().AmountWithBreakdown;
            //Console.WriteLine("Total Amount: {0} {1}", amount.CurrencyCode, amount.Value);
            ////Console.WriteLine("Response JSON: \n {0}", response.AsJson());
        }

        return response;
    }

    /// <summary>
    /// Below function can be used to build the create order request body with minimum payload.
    /// </summary>
    //private static OrderRequest BuildRequestBodyWithMinimumFields()
    //{
    //    var orderRequest = new OrderRequest
    //    {
    //        CheckoutPaymentIntent = EOrderIntent.Authorize,
    //        ApplicationContext = new ApplicationContext
    //        {
    //            CancelUrl = "https://www.example.com",
    //            ReturnUrl = "https://www.example.com"
    //        },
    //        PurchaseUnits = new List<PurchaseUnitRequest>
    //        {
    //            new()
    //            {
    //                AmountWithBreakdown = new AmountWithBreakdown
    //                {
    //                    CurrencyCode = "USD",
    //                    Value = "220.00"
    //                }
    //            }
    //        }
    //    };

    //    return orderRequest;
    //}

   
}
