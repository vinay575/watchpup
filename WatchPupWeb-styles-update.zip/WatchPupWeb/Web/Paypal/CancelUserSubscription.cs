using PayPal.Sdk.Checkout.Authentication;
using PayPal.Sdk.Checkout.ContractEnums;
using PayPal.Sdk.Checkout.Core.Interfaces;
using PayPal.Sdk.Checkout.Extensions;
using PayPal.Sdk.Checkout.Subscriptions;
using System;
using System.Threading.Tasks;
using DataAccessLibrary.Models;


namespace WatchPupWeb.Paypal;

public static class CancelUserSubscription
{
    /// <summary>
    /// Below function can be used to build the create order request body with complete payload.
    /// </summary>
    
    private static SubscriptionRequest BuildRequestBody()
    {
        var subscriptionRequest = new SubscriptionRequest
        {
            Reason = "User cancelled the Subscription."
            
        };
            
        return subscriptionRequest;
    }

    /// <summary>
    /// Below function can be used to create a subscription with complete payload.
    /// </summary>
    public static async Task<Subscription?> CancelSubscription(this IPayPalHttpClient httpClient, AccessToken accessToken, string subscriptionId, bool debug = false)
    {
        Console.WriteLine("Cancel Subscription with complete payload");
        var response = await httpClient.CancelSubscriptionAsync(accessToken, subscriptionId,  request =>
        {
            request.SetPreferReturn(EPreferReturn.Representation);
            request.SetRequestBody(BuildRequestBody());
        });

        if (debug && response != null)
        {
        }

        return response;
    }

    /// <summary>
    /// Below function can be used to build the create order request body with minimum payload.
    /// </summary>
    //private static OrderRequest BuildRequestBodyWithMinimumFields()
    //{
    //    var orderRequest = new OrderRequest
    //    {
    //        CheckoutPaymentIntent = EOrderIntent.Authorize,
    //        ApplicationContext = new ApplicationContext
    //        {
    //            CancelUrl = "https://www.example.com",
    //            ReturnUrl = "https://www.example.com"
    //        },
    //        PurchaseUnits = new List<PurchaseUnitRequest>
    //        {
    //            new()
    //            {
    //                AmountWithBreakdown = new AmountWithBreakdown
    //                {
    //                    CurrencyCode = "USD",
    //                    Value = "220.00"
    //                }
    //            }
    //        }
    //    };

    //    return orderRequest;
    //}

   
}
