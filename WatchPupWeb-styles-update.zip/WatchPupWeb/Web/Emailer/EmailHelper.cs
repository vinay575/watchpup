﻿using System.Net.Mail;
using System.Net;
using WatchPupWeb.Data;

namespace WatchPupWeb.Emailer
{
    public class EmailHelper
    {
        private string emailBody;
        private string verificationId;

        public void BuildandSend(EmailParameters emailParameters)

        {
            if (emailParameters.EmailType == EmailType.Verification)
            {
                emailParameters.Subject = "WatchPup Emailid Verification";
                emailParameters.Body = EmailerUtil.VerificationEmailBody;
                emailParameters.VerificationId = emailParameters.VerificationId;
                emailParameters.Body = emailParameters.Body.Replace("@verificationLink", EmailerUtil.VerificationURL);
                emailParameters.Body = emailParameters.Body.Replace("@verificationId", emailParameters.VerificationId);

                Send(emailParameters);
            }
            else if (emailParameters.EmailType == EmailType.ForgotPassword)
            {
                emailParameters.Subject = "WatchPup Forgot Password";
                emailParameters.Body = EmailerUtil.ForgotPasswordEmailBody;
                emailParameters.ForgotPasswordId = emailParameters.ForgotPasswordId;
                emailParameters.Body = emailParameters.Body.Replace("@forgotPasswordLink", EmailerUtil.ForgotPasswordURL);
                emailParameters.Body = emailParameters.Body.Replace("@forgotpasswordId", emailParameters.ForgotPasswordId);

                Send(emailParameters);
            }
            else if (emailParameters.EmailType == EmailType.LicenseId)
            {
                emailParameters.Subject = "WatchPup Installation Link";
                emailParameters.Body = EmailerUtil.LicenseEmailBody;
                emailParameters.Body = emailParameters.Body.Replace("@installationLink", EmailerUtil.InstallationURL);
                emailParameters.Body = emailParameters.Body.Replace("@contactUsLink", EmailerUtil.ContactUsURL);
                emailParameters.Body = emailParameters.Body.Replace("@licenseId", emailParameters.LicenseId);
            
                Send(emailParameters);
            }
        }


        public void Send(EmailParameters emailParameters)
        {
            // Create a MailMessage
            MailMessage mailMessage = new MailMessage();
            mailMessage.Subject = emailParameters.Subject;
            mailMessage.Body = emailParameters.Body;
            mailMessage.IsBodyHtml = true;


            // Configure the SMTP client
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
            smtpClient.Port = 587;
            smtpClient.Credentials = new NetworkCredential("watchpupalertsystem1", "nrle mrjc epmm upbh");
            smtpClient.EnableSsl = true;

            // Set sender and recipient email addresses

            mailMessage.From = new MailAddress("watchpupalertsystem1@gmail.com");
            mailMessage.To.Add(emailParameters.ToEmailAddress);

            // Send the email
            smtpClient.Send(mailMessage);
        }
    }
}



