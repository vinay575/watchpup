using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class Name1
    {
        [JsonPropertyName("full_name")]
        public string? FullName { get; set; }
    }
}
