using System;
using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class LastPayment
    {
        [JsonPropertyName("amount")]
        public Amount? Amount { get; set; }

        [JsonPropertyName("time")]
        public DateTime? Time { get; set; }
    }
    
}
