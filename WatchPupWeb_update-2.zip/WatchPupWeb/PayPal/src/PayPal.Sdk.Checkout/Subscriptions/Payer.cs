using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class Payer
    {
        [JsonPropertyName("payment_method")]
        public string? PaymentMethod { get; set; }

        [JsonPropertyName("funding_instruments")]
        public FundingInstruments[]? FundingInstruments { get; set; }

        //[JsonPropertyName("payer_info")]
        //public PayerInfo PayerInfo { get; set; }
    }
}
