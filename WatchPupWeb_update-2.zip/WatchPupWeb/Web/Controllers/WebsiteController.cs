using System.Collections.Generic;
using DataAccessLibrary;
using DataAccessLibrary.Interfaces;
using DataAccessLibrary.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace WatchPupWeb.Controllers
{
    [ApiController]
    [Microsoft.AspNetCore.Mvc.Route("[controller]")]
    public class WebsiteController : ControllerBase
    {
        IWebsite _db;
        ISqlDataAccess sqlDataAccess;

        private readonly IConfiguration _configuration;
        private WebsiteModel websiteModel = new WebsiteModel();
        List<WebsiteModel> websiteList = null;

        private readonly ILogger<WebsiteController> _logger;

        public WebsiteController(IConfiguration configuration)
        {
            //_logger = logger;
            _configuration = configuration;
        }

        [HttpGet(Name = "GetWebsiteDetails")]
        public WebsiteModel GetWebsiteDetails()
        {
            sqlDataAccess = new SqlDataAccess(_configuration);
            _db = new WebsiteData(sqlDataAccess);

            websiteList = _db.GetWebsiteDetails(websiteModel);

            if (websiteList?.Count == 1)
            {
                websiteModel = (WebsiteModel)websiteList[0];
            }

            return websiteModel;
        }
    }
 }
