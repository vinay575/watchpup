using System.Collections.Generic;
//using System.Net.Http;
//using System.Threading.Tasks;
using DataAccessLibrary;
using DataAccessLibrary.Interfaces;
using DataAccessLibrary.Models;
//using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
//using WatchPupWeb.Paypal;

namespace WatchPupWeb.Controllers
{
    [ApiController]
    [Microsoft.AspNetCore.Mvc.Route("[controller]")]
    public class SubscriptionController : ControllerBase
    {
        ISubscription _db;
        ISqlDataAccess sqlDataAccess;

        private readonly IConfiguration _configuration;

        List<UserSubscriptionModel> subscriptionList = null;

        private readonly ILogger<SubscriptionController> _logger;

        public SubscriptionController(IConfiguration configuration)
        {
            //_logger = logger;
            _configuration = configuration;
        }

        [HttpGet(Name = "GetUserSubscription")]
        public UserSubscriptionModel GetUserSubscription(string lIcenseId)
        {
            sqlDataAccess = new SqlDataAccess(_configuration);
            _db = new SubscriptionData(sqlDataAccess);
            UserSubscriptionModel userSubscriptionModel = new UserSubscriptionModel
            {
                LicenseId = lIcenseId
            };

            subscriptionList = _db.GetCurrentUserSubscription(userSubscriptionModel);

            if (subscriptionList?.Count == 1)
            {
                userSubscriptionModel = (UserSubscriptionModel)subscriptionList[0];
            }

            return userSubscriptionModel;
        }
    }
 }
