using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WatchPupWeb.Pages
{
    public class testModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
