using PayPal.Sdk.Checkout.Authentication;
using PayPal.Sdk.Checkout.Core.Interfaces;
using PayPal.Sdk.Checkout.Subscriptions;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PayPal.Sdk.Checkout.Extensions;

public static class SubscriptionRequestExtensions
{
    public static Task<IPayPalHttpResponse<Subscription>> CreateSubscriptionRawAsync(
        this IPayPalHttpClient payPalHttpClient,
        AccessToken accessToken,
        Action<SubscriptionsCreateRequest>? configureRequest = null,
        CancellationToken cancellationToken = default
    )
    {
        var request = new SubscriptionsCreateRequest();

        configureRequest?.Invoke(request);

        return payPalHttpClient.ExecuteAsync<SubscriptionsCreateRequest, SubscriptionRequest, Subscription>(request, accessToken, cancellationToken);
    }

    public static async Task<Subscription?> CreateSubscriptionAsync(
        this IPayPalHttpClient payPalHttpClient,
        AccessToken accessToken,
        Action<SubscriptionsCreateRequest>? configureRequest = null,
        CancellationToken cancellationToken = default
    )
    {
        var response = await payPalHttpClient.CreateSubscriptionRawAsync(
            accessToken,
            configureRequest,
            cancellationToken
        );

        return response.ResponseBody;
    }

    public static Task<IPayPalHttpResponse<Subscription>> ShowSubscriptionDetailsRawAsync(
        this IPayPalHttpClient payPalHttpClient,
        AccessToken accessToken,
        string subscriptionId,
        Action<SubscriptionsShowDetailsRequest>? configureRequest = null,
        CancellationToken cancellationToken = default
    )
    {
        var request = new SubscriptionsShowDetailsRequest(subscriptionId);

        configureRequest?.Invoke(request);

        return payPalHttpClient.ExecuteAsync<SubscriptionsShowDetailsRequest, SubscriptionRequest, Subscription>(request, accessToken, cancellationToken);
    }

    public static async Task<Subscription?> ShowSubscriptionDetailsAsync(
       this IPayPalHttpClient payPalHttpClient,
       AccessToken accessToken,
       string subscriptionId,
       Action<SubscriptionsShowDetailsRequest>? configureRequest = null,
       CancellationToken cancellationToken = default
    )
    {
        var response = await payPalHttpClient.ShowSubscriptionDetailsRawAsync(
            accessToken,
            subscriptionId,
            configureRequest,
            cancellationToken
        );

        return response.ResponseBody;
    }

    public static Task<IPayPalHttpResponse<Subscription>> CancelSubscriptionRawAsync(
        this IPayPalHttpClient payPalHttpClient,
        AccessToken accessToken,
        string subscriptionId,
        Action<SubscriptionsCancelRequest>? configureRequest = null,
        CancellationToken cancellationToken = default
    )
    {
        var request = new SubscriptionsCancelRequest(subscriptionId);

        configureRequest?.Invoke(request);

        return payPalHttpClient.ExecuteAsync<SubscriptionsCancelRequest, SubscriptionRequest, Subscription>(request, accessToken, cancellationToken);
    }

    public static async Task<Subscription?> CancelSubscriptionAsync(
       this IPayPalHttpClient payPalHttpClient,
       AccessToken accessToken,
       string subscriptionId,
       Action<SubscriptionsCancelRequest>? configureRequest = null,
       CancellationToken cancellationToken = default
    )
    {
        var response = await payPalHttpClient.CancelSubscriptionRawAsync(
            accessToken,
            subscriptionId,
            configureRequest,
            cancellationToken
        );

        return response.ResponseBody;
    }

    /// <summary>
    /// Authorizes payment for an order. To successfully authorize payment for an order, the buyer must first approve the order or a valid payment_source must be provided in the request. A buyer can approve the order upon being redirected to the rel:approve URL that was returned in the HATEOAS links in the create order response.
    /// </summary>
    public static Task<IPayPalHttpResponse<Subscription>> AuthorizeSubscriptionRawAsync(
        this IPayPalHttpClient payPalHttpClient,
        AccessToken accessToken,
        string orderId,
        Action<SubscriptionsAuthorizeRequest>? configureRequest = null,
        CancellationToken cancellationToken = default
    )
    {
        var request = new SubscriptionsAuthorizeRequest(orderId);

        configureRequest?.Invoke(request);

        return payPalHttpClient.ExecuteAsync<SubscriptionsAuthorizeRequest, AuthorizeRequest, Subscription>(request, accessToken, cancellationToken);
    }

    /// <summary>
    /// Authorizes payment for an order. To successfully authorize payment for an order, the buyer must first approve the order or a valid payment_source must be provided in the request. A buyer can approve the order upon being redirected to the rel:approve URL that was returned in the HATEOAS links in the create order response.
    /// </summary>
    public static async Task<Subscription?> AuthorizeSubscriptionAsync(
        this IPayPalHttpClient payPalHttpClient,
        AccessToken accessToken,
        string orderId,
        Action<SubscriptionsAuthorizeRequest>? configureRequest = null,
        CancellationToken cancellationToken = default
    )
    {
        var response = await payPalHttpClient.AuthorizeSubscriptionRawAsync(
            accessToken,
            orderId,
            configureRequest,
            cancellationToken
        );

        return response.ResponseBody;
    }

    /// <summary>
    /// Captures payment for an order. To successfully capture payment for an order, the buyer must first approve the order or a valid payment_source must be provided in the request. A buyer can approve the order upon being redirected to the rel:approve URL that was returned in the HATEOAS links in the create order response.
    /// </summary>
    //public static Task<IPayPalHttpResponse<Order>> CaptureSubscriptionRawAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    Action<OrdersCaptureRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    var request = new OrdersCaptureRequest(orderId);

    //    configureRequest?.Invoke(request);

    //    return payPalHttpClient.ExecuteAsync<OrdersCaptureRequest, OrderActionRequest, Order>(request, accessToken, cancellationToken);
    //}

    ///// <summary>
    ///// Captures payment for an order. To successfully capture payment for an order, the buyer must first approve the order or a valid payment_source must be provided in the request. A buyer can approve the order upon being redirected to the rel:approve URL that was returned in the HATEOAS links in the create order response.
    ///// </summary>
    //public static async Task<Order?> CaptureSubscriptionAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    Action<OrdersCaptureRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    var response = await payPalHttpClient.CaptureSubscriptionRawAsync(
    //        accessToken,
    //        orderId,
    //        configureRequest,
    //        cancellationToken
    //    );

    //    return response.ResponseBody;
    //}

    //public static Task<IPayPalHttpResponse<Order>> GetSubscriptionRawAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    Action<OrdersGetRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    var request = new OrdersGetRequest(orderId);

    //    configureRequest?.Invoke(request);

    //    return payPalHttpClient.ExecuteAsync<OrdersGetRequest, Order>(request, accessToken, cancellationToken);
    //}

    //public static async Task<Order?> GetSubscriptionAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    Action<OrdersGetRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    var response = await payPalHttpClient.GetSubscriptionRawAsync(
    //        accessToken,
    //        orderId,
    //        configureRequest,
    //        cancellationToken
    //    );

    //    return response.ResponseBody;
    //}

    //public static async Task<IPayPalHttpResponse> SubscriptionsPatchRequestRawAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    IReadOnlyCollection<StringPatch> patchObjects,
    //    Action<OrdersStringPatchRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    var request = new OrdersStringPatchRequest(orderId);

    //    request.SetRequestBody(patchObjects);

    //    configureRequest?.Invoke(request);

    //    return await payPalHttpClient.ExecuteVoidAsync<OrdersStringPatchRequest, IReadOnlyCollection<StringPatch>>(request, accessToken, cancellationToken);
    //}

    //public static Task OrdersPatchRequestAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    IReadOnlyCollection<StringPatch> patchObjects,
    //    Action<OrdersStringPatchRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    return payPalHttpClient.OrdersPatchRequestRawAsync(accessToken, orderId, patchObjects, configureRequest, cancellationToken);
    //}

    //public static async Task<IPayPalHttpResponse<Order>> ValidateOrderRawAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    Action<OrdersValidateRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    var request = new OrdersValidateRequest(orderId);

    //    configureRequest?.Invoke(request);

    //    return await payPalHttpClient.ExecuteAsync<OrdersValidateRequest, OrderActionRequest, Order>(request, accessToken, cancellationToken);
    //}

    //public static async Task<Order?> ValidateOrderAsync(
    //    this IPayPalHttpClient payPalHttpClient,
    //    AccessToken accessToken,
    //    string orderId,
    //    Action<OrdersValidateRequest>? configureRequest = null,
    //    CancellationToken cancellationToken = default
    //)
    //{
    //    var response = await payPalHttpClient.ValidateOrderRawAsync(accessToken, orderId, configureRequest, cancellationToken);

    //    return response.ResponseBody;
    //}
}
