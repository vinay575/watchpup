using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class ShippingAmount
    {
        [JsonPropertyName("currency_code")]
        public string? CurrencyCode { get; set; }

        [JsonPropertyName("value")]
        public string? Value { get; set; }
    }
}
