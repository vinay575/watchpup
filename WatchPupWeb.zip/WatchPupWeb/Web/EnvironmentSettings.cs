﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using WatchPupWeb.Data;
using WatchPupWeb.Emailer;

namespace WatchPupWeb
{
    public class EnvironmentSettings
    {
        private readonly IConfiguration _config;
        public EnvironmentSettings(IConfiguration config)
        {
            _config = config;
            InitiateDataUtil();
            InitiateEmailSettings();
        }

        
        public void InitiateDataUtil()
        {
            DataUtil.Environment = _config?.GetSection("Environment")?.Value;

            if (DataUtil.Environment.Equals("Development"))
            {
                DataUtil.CancelURL = _config?.GetSection("Development")?["CancelURL"];
                DataUtil.ReturnURL = _config?.GetSection("Development")?["ReturnURL"];

            }
            else if (DataUtil.Environment.Equals("Production"))
            {
                DataUtil.CancelURL = _config?.GetSection("Production")?["CancelURL"];
                DataUtil.ReturnURL = _config?.GetSection("Production")?["ReturnURL"];
            }
        }

        public void InitiateEmailSettings() 
        {
            //_config?.GetSection("Development")?["Test1"]
            if (DataUtil.Environment.Equals("Development"))
            {
                EmailerUtil.VerificationURL = _config?.GetSection("Development")?["VerificationURL"];
                EmailerUtil.VerificationRequestURL =  _config?.GetSection("Development")?["VerificationRequestURL"];
            }
            else if (DataUtil.Environment.Equals("Production"))
            {
                EmailerUtil.VerificationURL = _config?.GetSection("Production")?["VerificationURL"];
                EmailerUtil.VerificationRequestURL = _config?.GetSection("Production")?["VerificationRequestURL"];
            }

            //var myService = HttpContext.RequestServices.GetService<WatchPupWeb.Data.GlobalVariables>();
            //var globalVariables = (WatchPupWeb.Data.GlobalVariables)HttpContext.RequestServices.GetService(typeof(WatchPupWeb.Data.GlobalVariables));
        }
    }

    
}
