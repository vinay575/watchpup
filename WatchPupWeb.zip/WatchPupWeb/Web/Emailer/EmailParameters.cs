﻿using Microsoft.AspNetCore.Mvc.Routing;

namespace WatchPupWeb.Emailer
{
    public class EmailParameters
    {
        public EmailType EmailType { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string VerificationId { get; set; }
        public string ForgotPasswordId { get; set; }
        public string URL { get; set; }
        public string ToEmailAddress { get; set; }
    }

    public enum EmailType
    {
        Verification,
        ForgotPassword

    }
}


