﻿using System.Text;

namespace WatchPupWeb.Emailer
{
    public static class EmailerUtil
    {
        //public static string ConnectionString = string.Empty;
        public static string VerificationURL = string.Empty;
        public static string VerificationRequestURL = string.Empty;
        //public static string VerificationURL = "\"https://localhost:5001/verification?id=@verificationId\"";
        //public static string VerificationRequestURL = "\"https://localhost:5001/verificationrequest\"";

        // static string VerificationURL = "\"http://sgsmarteraspnet-001-site1.ktempurl.com/verification?id=@verificationId\"";
        //public static string VerificationRequestURL = "\"http://sgsmarteraspnet-001-site1.ktempurl.com/verificationrequest\"";

        //public static string VerificationEmailBody = @"<!DOCTYPE html>";
        //<html>";


        //<head>
        //  <title>Verify your email address</title>
        //</head>
        //<body>
        //  <h1>Verify your email address</h1>
        //  <p>Please click on the following link to verify your email address:</p>
        //  <a href="@verificationLink">Verify your email address</a>
        //  <p> If you do not click on the link within 24 hours, your email address will not be verified.</p>
        //  <p> Thank you for signing up!</p>
        //</body>
        //</html>
        //";

        public static string VerificationEmailBody = @"<!DOCTYPE html>
        <html>
        <head>
          <title>Verify your email address</title>
        </head>
        <body>
          <h1>Verify your email address</h1>
          <p>Please click on the following link to verify your email address:</p>
          <a href=@verificationLink>Verify your email address</a>
          <p>If you do not click on the link within 24 hours, your email address will not be verified.</p>
          <p>Thank you for signing up!</p>
        </body>
        </html>";

        public static string ForgotPasswordURL = "\"https://sgsmarteraspnet-001-site1.ktempurl.com/resetpassword?id=@forgotpasswordId\"";
        public static string ForgotPasswordRequestURL = "\"https://sgsmarteraspnet-001-site1.ktempurl.com/resetpasswordrequest\"";

        //public static string ForgotPasswordURL = "\"https://localhost:5001/resetpassword?id=@forgotpasswordId\"";
        //public static string ForgotPasswordRequestURL = "\"https://localhost:5001/resetpasswordrequest\"";
        public static string ForgotPasswordEmailBody = @"<!DOCTYPE html>
        <html>
        <head>
          <title>Forgot Password</title>
        </head>
        <body>
          <h1>Reset Password</h1>
          <p>Please click on the following link to reset password:</p>
          <a href=@forgotPasswordLink>Reset Password</a>
          <p>If you do not click on the link within 24 hours, this link would expire.</p>
          <p>Thank you!</p>
        </body>
        </html>";
    }
}


