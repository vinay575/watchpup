﻿using System.Net.Mail;
using System.Net;

namespace WatchPupWeb.Emailer
{
    public class EmailHelper
    {
        private string emailBody;
        private string verificationId;

        public void BuildandSend(EmailParameters emailParameters)

        {
            if (emailParameters.EmailType == EmailType.Verification)
            {
                emailParameters.Subject = "Sentinel Delivery EmailId Verification";
                emailParameters.Body = EmailerUtil.VerificationEmailBody;
                emailParameters.VerificationId = emailParameters.VerificationId;
                emailParameters.Body = emailParameters.Body.Replace("@verificationLink", EmailerUtil.VerificationURL);
                emailParameters.Body = emailParameters.Body.Replace("@verificationId", emailParameters.VerificationId);
                Send(emailParameters);
            }
            else if (emailParameters.EmailType == EmailType.ForgotPassword)
            {
                emailParameters.Subject = "Sentinel Delivery Forgot Password";
                emailParameters.Body = EmailerUtil.ForgotPasswordEmailBody;
                emailParameters.ForgotPasswordId = emailParameters.ForgotPasswordId;
                emailParameters.Body = emailParameters.Body.Replace("@forgotPasswordLink", EmailerUtil.ForgotPasswordURL);
                emailParameters.Body = emailParameters.Body.Replace("@forgotpasswordId", emailParameters.ForgotPasswordId);
                Send(emailParameters);
            }
        }


        public void Send(EmailParameters emailParameters)
        {
            // Create a MailMessage
            MailMessage mailMessage = new MailMessage();
            mailMessage.Subject = emailParameters.Subject;
            mailMessage.Body = emailParameters.Body;
            mailMessage.IsBodyHtml = true;


            // Configure the SMTP client
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
            smtpClient.Port = 587;
            smtpClient.Credentials = new NetworkCredential("gubbalasree11", "svrx nrts rpbx sfys");
            smtpClient.EnableSsl = true;

            // Set sender and recipient email addresses

            mailMessage.From = new MailAddress("gubbalasree@yahoo.com");
            mailMessage.To.Add(emailParameters.ToEmailAddress);

            // Send the email
            smtpClient.Send(mailMessage);
        }
    }
}



