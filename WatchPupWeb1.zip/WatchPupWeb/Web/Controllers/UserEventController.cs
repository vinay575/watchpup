using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;



//using System.Net.Http;
//using System.Threading.Tasks;
using DataAccessLibrary;
using DataAccessLibrary.Interfaces;
using DataAccessLibrary.Models;
//using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
//using WatchPupWeb.Paypal;

namespace WatchPupWeb.Controllers
{
    [ApiController]
    [Microsoft.AspNetCore.Mvc.Route("[controller]")]
    public class UserEventController : ControllerBase
    {
        IEvent _db;
        ISqlDataAccess sqlDataAccess;

        private readonly EventModel _context;
        private readonly IConfiguration _configuration;

        List<EventModel> subscriptionList = null;

        private readonly ILogger<WebsiteController> _logger;

        //public UserEventController(IConfiguration configuration)
        //{
        //    //_logger = logger;
        //    _configuration = configuration;
        //}

        

        //public UserEventController(IConfiguration configuration)
        //{
        //    _context = context;
        //}
        public UserEventController(IConfiguration configuration)
        {
            //_logger = logger;
            _configuration = configuration;
        }

        [HttpPut]
        public EventModel LogEvent([FromBody]EventModel eventModel)
        {
            sqlDataAccess = new SqlDataAccess(_configuration);
            _db = new EventData(sqlDataAccess);

            //EventModel eventModel = new EventModel
            //{
            //    LicenseId = LicenseId,
            //    MachineName = MachineName,
            //    UserName = UserName,
            //    EventDateTime = EventDateTime
            //};

            //string authorizationValue = Request.HttpContext.Request.Headers["machinename"];

            //IEnumerable<string> headerValues;
            //if (Request.Headers.TryGetValue("MyCustomID", out (Microsoft.Extensions.Primitives.StringValues)headerValues))
            //{
            //    var id = headerValues.FirstOrDefault();
            //    // Now you can use the 'id' value as needed
            //}

            //if (Request.Headers.TryGetValue("MachineName", out var headerValues))
            //{
            //    string headerValue = headerValues.FirstOrDefault();
            //    // Use the header value as needed
            //    //return Ok(headerValue);
            //}

            _db.InsertEvent(eventModel);

            //sqlDataAccess = new SqlDataAccess(_configuration);
            //_db = new WebsiteData(sqlDataAccess);

            //websiteList = _db.GetWebsiteDetails(websiteModel);

            //if (websiteList?.Count == 1)
            //{
            //    websiteModel = (WebsiteModel)websiteList[0];
            //}

            return null;
            //return Ok();
        }
    }
 }
