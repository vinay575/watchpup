﻿using DataAccessLibrary.Interfaces;
using Microsoft.VisualBasic;
using PayPal.Sdk.Checkout.Subscriptions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Numerics;
using System.Reflection.PortableExecutable;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Intrinsics.X86;
using System.Threading;
using System.Threading.Tasks;
using WatchPupWeb.Pages;
namespace WatchPupWeb.Models
{
    public class RegisterUserViewModel
    {
        public RegisterUserViewModel()
        {
            _disclaimer = "We prioritize the privacy and security of personal information.When providing your email address, ";
            _disclaimer += "please ensure it is both accurate and actively in use.We cannot be held responsible for any documents ";
            _disclaimer += "sent to an incorrect or inactive email address that you provide.It is your sole responsibility to verify ";
            _disclaimer += "the correctness of your email address prior to submission.Any loss of confidentiality or failure to receive ";
            _disclaimer += "documents due to an incorrect email address provided will be the responsibility of the individual providing ";
            _disclaimer += "the email address.";
            _disclaimer += "\n\nWe leverage an SMTP server to deliver emails, which are then purged from the server after being stored for 7 business days. ";
            _disclaimer += "\n\nThis license grants usage rights for up to two machines per subscription.";
            _disclaimer += "Our audit system monitors the number of active installations.In the event that usage on more than two systems ";
            _disclaimer += "is detected, we will issue two warning emails requesting the uninstallation from the additional machine(s). ";
            _disclaimer += "Failure to comply with these warnings will result in the cancellation of your subscription.";
            //_disclaimer = "We take the privacy and security of personal information seriously. ";
            //_disclaimer += "Please ensure that the email address provided is accurate and currently active.";
            //_disclaimer += "We are not responsible for any documents sent to an incorrect or invalid email address provided by you.";
            //_disclaimer += "It is your responsibility to verify the correctness of the email address before submission.Any loss of confidentiality ";
            //_disclaimer += "or failure to receive documents due to an incorrect email address is solely the responsibility of the individual providing the email address.";
        }
    [Required]
    [EmailAddress]
    public string Email { get; set; }
    [Required]
    public string Password { get; set; }
    [Required]
    [StringLength(15, ErrorMessage = "First Name is too long.")]
    [MinLength(2, ErrorMessage = "First Name is too short.")]
    public string FirstName { get; set; }
    [Required]
    [StringLength(15, ErrorMessage = "Last Name is too long.")]
    [MinLength(5, ErrorMessage = "Last Name is too short.")]
    public string LastName { get; set; }
    [Required(ErrorMessage = "You must accept the terms.")]
    public string AgreeTermsConditions { get; set; }
    public string Country { get; set; }
    public string IsInterviewer { get; set; }
    public string VerficationId { get; set; }
    public string LinkedinURL { get; set; }
    public string VerficationURL { get; set; }
    string _disclaimer;
    public string Disclaimer
    {
        get { return _disclaimer; }
        set { _disclaimer = value; }
    }
    }
}
