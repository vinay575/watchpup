﻿using System.Text;

namespace WatchPupWeb.Emailer
{
    public static class EmailerUtil
    {
        //public static string ConnectionString = string.Empty;
        public static string VerificationURL = string.Empty;
        //public static string VerificationRequestURL = string.Empty;
        //public static string VerificationURL = "\"https://localhost:5001/verification?id=@verificationId\"";
        //public static string VerificationRequestURLDev = "\"https://localhost:5001/verificationrequest\"";

        //public static string VerificationURLProd = "\"http://www.watchpup.us/verification?id=@verificationId\"";
        //public static string VerificationRequestURLProd = "\"http://www.watchpup.us/verificationrequest\"";

        //public static string VerificationEmailBody = @"<!DOCTYPE html>";
        //<html>";


        //<head>
        //  <title>Verify your email address</title>
        //</head>
        //<body>
        //  <h1>Verify your email address</h1>
        //  <p>Please click on the following link to verify your email address:</p>
        //  <a href="@verificationLink">Verify your email address</a>
        //  <p> If you do not click on the link within 24 hours, your email address will not be verified.</p>
        //  <p> Thank you for signing up!</p>
        //</body>
        //</html>
        //";

        public static string VerificationEmailBody = @"<!DOCTYPE html>
        <html>
        <head>
          <title>Verify your email address</title>
        </head>
        <body>
          <h1>Verify your email address</h1>
          <p>Please click on the following link to verify your email address:</p>
          <a href=@verificationLink>Verify your email address</a>
          <p>If you do not click on the link within 24 hours, your email address will not be verified.</p>
          <p>For any further assistance, please email us at watchpupsupport@gmail.com</p>
          <p>Sincerely,</p>
          <p>WatchPup Team</p>
          <p><a href=@contactusLink>Click to ContactUs</a></p>
        </body>
        </html>";

        public static string ForgotPasswordURL = string.Empty;

        //public static string ForgotPasswordURLDev = "\"https://localhost:5001/resetpassword?id=@forgotpasswordId\"";
        //public static string ForgotPasswordRequestURLDev = "\"https://localhost:5001/resetpasswordrequest\"";

        //public static string ForgotPasswordURLProd = "\"https://www.watchpup.us/resetpassword?id=@forgotpasswordId\"";
        //public static string ForgotPasswordRequestURLProd = "\"https://www.watchpup.us/resetpasswordrequest\"";
        
        public static string ForgotPasswordEmailBody = @"<!DOCTYPE html>
        <html>
        <head>
          <title>Forgot Password</title>
        </head>
        <body>
          <h1>Reset Password</h1>
          <p>Please click on the following link to reset password:</p>
          <a href=@forgotPasswordLink>Reset Password</a>
          <p>If you do not click on the link within 24 hours, this link would expire.</p>
          <p>For any further assistance, please email us at watchpupsupport@gmail.com</p>
          <p>Sincerely,</p>
          <p>WatchPup Team</p>
          <p><a href=@contactusLink>Click to ContactUs</a></p>
        </body>
        </html>";

        public static string InstallationURL = string.Empty;
        public static string ContactUsURL = string.Empty;
        //public static string InstallationURL = "\"https://localhost:5001/download/publish.html\"";
        //public static string InstallationURLProd = "\"https://www.watchpup.us/download/publish.html\"";

        public static string LicenseEmailBody = @"<!DOCTYPE html>
        <html>
        <head>
          <title>Installation and License Key</title>
        </head>
        <body>
          <h3>Thank you for your subscription.</h3>
          <h3>Please follow below instructions to install WatchPup application.</h3>
          <p>Step 1: Installation</p>
          <p>Please click on the following link to install the application on your machine:</p>
          <a href=@installationLink>Click to install WatchPup Application</a>
          <p>Step 2: Enter License Key</p>
          <p>After installation of the application. On the task bar you would see an icon with a Pup image.</p>
          <p>Click on the pup then application would open up, enter License Key provided below and click Apply.</p>
          <p>License Key: @licenseId</p>
          <p>Yay you are all set.</p>
          <p>Step 3: Stealth Mode (Not required if you do not want to hide the application)</p>
          <p>Login to www.watchup.us and click Update Profile and set the Stealth Mode to Yes, Click Update.</p>
          <p>Now restart your machine and WatchPup will not be visible but works in the background.</p><br><br>
          <p>If you have any questions, concerns or assistance. Please click on this link <a href=@contactUsLink>Contact Us.</a></P>
          <p>Thank you once again!</p>
          <p><a href=@contactusLink>Click to ContactUs</a></p>
        </body>
        </html>";
    }
}


