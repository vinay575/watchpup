using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class Subscriber
    {
        [JsonPropertyName("name")]
        public Name? Name { get; set; }

        [JsonPropertyName("email_address")]
        public string? EmailAddress { get; set; }

        [JsonPropertyName("shipping_address")]
        public ShippingAddress? ShippingAddress { get; set; }

        [JsonPropertyName("payer")]
        public Payer? payer { get; set; }
    }
}
