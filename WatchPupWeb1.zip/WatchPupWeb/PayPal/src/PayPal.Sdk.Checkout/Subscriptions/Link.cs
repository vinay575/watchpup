using System.Text.Json.Serialization;

namespace PayPal.Sdk.Checkout.Subscriptions
{
    public class Link
    {
        [JsonPropertyName("href")]
        public string? Href { get; set; }

        [JsonPropertyName("rel")]
        public string? Rel { get; set; }

        [JsonPropertyName("method")]
        public string? Method { get; set; }
    }
}
