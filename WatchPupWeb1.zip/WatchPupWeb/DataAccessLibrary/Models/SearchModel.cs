﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLibrary.Models
{
    public class SearchModel
    {
        public string searchCriteria { get; set; }
    }
}
